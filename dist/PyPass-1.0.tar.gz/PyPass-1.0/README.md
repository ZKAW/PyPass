# PyPass
This is a random password generator coded in Python.
-> This script do not store ANY of your data.

**Where can I use it?:**

- Windows (.exe compiled version available)
- Ubuntu
- macOS

**With this script, you can:**

- Select the password length
- Enable/disable numbers
- Enable/disable special chars
- Change the special char list

**HOW TO DOWNLOAD:**

* `git clone https://github.com/ZKAW/PyPass`
<br/> or <br/>
* Download the .zip [by clicking here](https://github.com/ZKAW/PyPass/archive/master.zip)


**HOW TO LAUNCH:**

Launch the script with: `python3 PyPass.py` (python3 required)
<br/>
Or just launch the .exe (python not required)
<br/>

**HOW TO HELP ME:**

- Like
- Fork
- Tell your friend about this ! :)

**! DISCLAIMER !**

This script is not storing ANY of your data, so you can use it in a totally transparent and safe way. Enjoy ! :)
